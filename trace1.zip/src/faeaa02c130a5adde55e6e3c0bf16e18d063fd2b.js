const { test, expect } = require('@playwright/test');
const { uploadResult } = require('../resultUploder/uploadResult');




test.beforeEach(async ({ context }) => {
  await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
});

test.afterEach(async ({ context }, testInfo) => {
  await context.tracing.stop({ path: testInfo.outputPath('trace.zip') });

const testData = testInfo.tags.map(tag => tag.replace(/^@/, ""));
const testname  = testData[0];
const releaseVersion = testData[1];

if (releaseVersion) {
  await uploadResult(testname, releaseVersion);
} else {
  console.log("No release version tag found. Skipping upload.");
}

 
});



test("Playwright dashboard test @playwrigthtest for @2704", async ({ page,context }, testInfo) => {

  console.log(testInfo.title);
  console.log(testInfo.tags);

  await page.goto('https://playwright.com');

  await page
    .locator('xpath=//div[contains(concat(\' \', normalize-space(@class), \' \'), \' theme-layout-navbar-left \')]')
    .waitFor({ state: 'visible' });

  await page.getByText('Get started').click();

  await expect(page).toHaveURL('https://playwright.dev/docs/intro');

  console.log(`Test finished with status: ${testInfo.status}`);

});

